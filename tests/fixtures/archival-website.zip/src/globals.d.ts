declare global {
  const DEV: boolean;
}
