#!/bin/bash

rm archival-website.zip
cd archival-website
zip -r ../archival-website.zip * .*
cd -
